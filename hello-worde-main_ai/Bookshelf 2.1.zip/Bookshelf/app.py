from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'bookshelf_secret_key'

# Banco de dados simulado (Mock) com links para e-books online
USUARIOS = {}
LIVROS_MOCK = [
    {
        "id": 1,
        "titulo": "Desbravando Java e Orientação a Objetos",
        "autor": "Rodrigo Turini",
        "formato": "PDF",
        "tamanho": "4.8 MB",
        "progresso": 35,
        "paginas": "032 - 323 PÁG.",
        "link_leitura": "https://archive.org" # Link simulado/exemplo
    },
    {
        "id": 2,
        "titulo": "Java - Como Programar",
        "autor": "Paul Deitel, Harvey Deitel",
        "formato": "PDF",
        "tamanho": "22 MB",
        "progresso": 12,
        "paginas": "050 - 960 PÁG.",
        "link_leitura": "https://archive.org" # E-book online real
    },
    {
        "id": 3,
        "titulo": "Box HP Lovecraft: Os melhores contos",
        "autor": "Lovecraft H.P.",
        "formato": "EPUB",
        "tamanho": "3,9 MB",
        "progresso": 85,
        "paginas": "210 - 245 PÁG.",
        "link_leitura": "https://gutenberg.org" # E-book online real (Gutenberg)
    }
]

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        
        # Validação simples
        if email in USUARIOS and USUARIOS[email]['senha'] == senha:
            return redirect(url_for('biblioteca'))
        else:
            flash("Usuário ou senha incorretos.", "error")
    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('senha')
        cpf = request.form.get('cpf')
        
        if email in USUARIOS:
            flash("E-mail já cadastrado.", "error")
        else:
            USUARIOS[email] = {'nome': nome, 'senha': senha, 'cpf': cpf}
            flash("Cadastro realizado com sucesso!", "success")
            return redirect(url_for('login'))
            
    return render_template('cadastro.html')

@app.route('/biblioteca')
def biblioteca():
    busca = request.args.get('q', '')
    livros_filtrados = LIVROS_MOCK
    
    if busca:
        livros_filtrados = [l for l in LIVROS_MOCK if busca.lower() in l['titulo'].lower() or busca.lower() in l['autor'].lower()]
        
    return render_template('biblioteca.html', livros=livros_filtrados, busca=busca)

if __name__ == '__main__':
    # Executa o servidor localmente
    app.run(debug=True)
